import "../scss/Main.scss";
// import "./pre-loader";
import "./side-bar";
import "./elements-home";
import "./marquee";
import "./card";
import "./faq-toggle";
import "./ing-secction";
import "./slider";
import "./cart";
import "./horizontal-text";


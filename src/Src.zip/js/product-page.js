import "../scss/Main.scss";
import "./side-bar";
import "./marquee";
import "./product-cmp";
import "./cart";
import "./ing-secction";
import "./faq-toggle";
// config.js
const CONFIG = {
    BACKEND_URL: 'https://jww-backend-main-production.up.railway.app'
};
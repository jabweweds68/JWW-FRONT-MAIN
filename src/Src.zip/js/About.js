import gsap from "gsap";
import "../scss/Main.scss"
import "./faq-toggle";
import "./marquee";
import "./side-bar";
import "./ing-secction";
import "./card";
import "./cart";
import "../scss/Main.scss";
import "./side-bar";
import "./marquee";
import "./faq-toggle";
import "./cart";